import React from 'react'

function GalleryDetail({isHidden}) {
  return (
    <div className={`fixed h-screen right-10 left-10 backdrop-blur-2xl top-0 bottom-0 z-50 ${isHidden} `}>
      <div>

      </div>
      
    </div>
  )
}

export default GalleryDetail
