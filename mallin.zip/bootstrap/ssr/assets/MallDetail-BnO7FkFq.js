import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "react";
import { G as GetTheApp } from "./GetTheApp-BwTlhFun.js";
import { H as Header } from "./Header-COyX0vDs.js";
import Slider from "react-slick";
import { M as MyFooter } from "./MyFooter-C_fqmKH9.js";
import "react-image-gallery";
import { faLink, faCamera, faDumbbell, faBed } from "@fortawesome/free-solid-svg-icons";
import "@fortawesome/free-brands-svg-icons";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "@inertiajs/react";
function Amenity({ icon1, icon2, icon3, title1, title2, title3 }) {
  return /* @__PURE__ */ jsxs("ul", { className: "py-5 flex flex-col gap-y-2", children: [
    /* @__PURE__ */ jsxs("li", { className: "gap-x-3 flex items-center", children: [
      /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: icon1, className: "text-greenish" }),
      title1
    ] }),
    /* @__PURE__ */ jsxs("li", { className: "gap-x-3 flex items-center", children: [
      /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: icon2, className: "text-greenish" }),
      title2
    ] }),
    /* @__PURE__ */ jsxs("li", { className: "gap-x-3 flex items-center", children: [
      /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: icon3, className: "text-greenish" }),
      title3
    ] })
  ] });
}
function SampleNextArrow(props) {
  const { className, style, onClick } = props;
  return /* @__PURE__ */ jsx(
    "div",
    {
      className,
      style: { ...style, display: "block", background: "black" },
      onClick
    }
  );
}
function SamplePrevArrow(props) {
  const { className, style, onClick } = props;
  return /* @__PURE__ */ jsx(
    "div",
    {
      className,
      style: { ...style, display: "block", background: "black" },
      onClick
    }
  );
}
function MallSlider() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2800,
    nextArrow: /* @__PURE__ */ jsx(SampleNextArrow, {}),
    prevArrow: /* @__PURE__ */ jsx(SamplePrevArrow, {})
  };
  const images = [
    "mall-1.jpg",
    "mall-2.jpg",
    "mall-3.jpg",
    "mall-4.jpg"
  ];
  images.map((i, j) => console.log(i));
  return /* @__PURE__ */ jsx("div", { className: "slider-container", children: /* @__PURE__ */ jsx(Slider, { ...settings, children: images.map((img, index) => /* @__PURE__ */ jsx("div", { className: "w-[300px] md:w-[500px] h-[400px] overflow-hidden max-w-[300px] mx-auto rounded-xl px-3", children: /* @__PURE__ */ jsx("img", { src: "/images/" + img, className: "object-cover h-full  rounded- w-full", alt: "Mall 2" }) })) }) });
}
function MallDetail() {
  const toggleMenu = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.toggle("hidden");
  };
  const toggleMenuClose = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.add("hidden");
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Header, { func1: toggleMenu, onclick: toggleMenuClose }),
    /* @__PURE__ */ jsxs("main", { onClick: toggleMenuClose, children: [
      /* @__PURE__ */ jsxs("section", { className: "max-w-[1200px] mx-auto py-10 px-5", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-3xl font-semibold", children: "Century Mall" }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center py-4 gap-x-3", children: [
          /* @__PURE__ */ jsx("img", { src: "images/ratings/rating-35.png", alt: "", className: "w-24" }),
          /* @__PURE__ */ jsxs("span", { children: [
            "(3.5) ",
            /* @__PURE__ */ jsxs("span", { children: [
              /* @__PURE__ */ jsx("span", { className: "underline", children: "2340" }),
              " reviews"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-x-3 items-center", children: [
          /* @__PURE__ */ jsx("a", { href: "#", className: "underline", children: "Website" }),
          /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faLink })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-x-4 py-2 md:flex-row flex-col", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsxs("strong", { children: [
              /* @__PURE__ */ jsx("span", { className: "md:hidden", children: "|" }),
              " 5"
            ] }),
            " Total Space ",
            /* @__PURE__ */ jsx("span", { className: "hidden md:block", children: "|" })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsxs("strong", { children: [
              /* @__PURE__ */ jsx("span", { className: "md:hidden", children: "|" }),
              " 8"
            ] }),
            " Free Space ",
            /* @__PURE__ */ jsx("span", { className: "hidden md:block", children: "|" })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsxs("strong", { children: [
              /* @__PURE__ */ jsx("span", { className: "md:hidden", children: "|" }),
              " 0"
            ] }),
            " Vacancy ",
            /* @__PURE__ */ jsx("span", { className: "hidden md:block", children: "|" })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsxs("strong", { children: [
              /* @__PURE__ */ jsx("span", { className: "md:hidden", children: "|" }),
              " 3"
            ] }),
            " Event ",
            /* @__PURE__ */ jsx("span", { className: "hidden md:block", children: "|" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("section", { className: "max-w-[300px] mx-auto py-10 px-5", children: /* @__PURE__ */ jsx(MallSlider, {}) }),
      /* @__PURE__ */ jsx("section", { className: "max-w-[1200px] mx-auto px-4 my-4", children: /* @__PURE__ */ jsxs("div", { className: "flex gap-x-5 md:flex-row flex-col", children: [
        /* @__PURE__ */ jsxs("div", { className: "md:w-[90%]", children: [
          /* @__PURE__ */ jsx("h1", { className: "text-3xl font-semibold", children: "Century Mall" }),
          /* @__PURE__ */ jsxs("p", { className: "py-5", children: [
            /* @__PURE__ */ jsx("a", { href: "#", className: "underline", children: "Lorem ipsum dolor sit" }),
            " amet consectetur adipisicing elit. Assumenda doloribus ad sint suscipit harum eius, accusantium at sequi impedit ratione molestiae delectus aliquam illum eos, magni nemo autem voluptatem minus dolores exercitationem ut nihil consequatur asperiores. Voluptates, hic at? Nemo vitae maiores optio vel ",
            /* @__PURE__ */ jsx("br", {}),
            /* @__PURE__ */ jsx("br", {}),
            " ",
            /* @__PURE__ */ jsx("a", { href: "#", className: "underline", children: "Error minima" }),
            " dolorum nihil deserunt assumenda ab. Eveniet recusandae saepe commodi nihil, minima hic dolores voluptas impedit accusantium dolorem ipsam qui fuga debitis animi temporibus voluptatibus quos nam aut possimus tempora placeat laboriosam tenetur. Commodi quod exercitationem enim vitae, reiciendis quo, neque voluptate nisi at cumque vel deleniti dolore aliquid fugiat aliquam. Molestias repellat ab sed.",
            /* @__PURE__ */ jsx("br", {}),
            /* @__PURE__ */ jsx("br", {}),
            " ",
            /* @__PURE__ */ jsx("a", { href: "#", className: "underline", children: "Error minima" }),
            " dolorum nihil deserunt assumenda ab. Eveniet recusandae saepe commodi nihil, minima hic dolores voluptas impedit accusantium dolorem ipsam qui fuga debitis animi temporibus voluptatibus quos nam aut possimus tempora placeat laboriosam tenetur. Commodi quod exercitationem enim vitae, reiciendis quo, neque voluptate nisi at cumque vel deleniti dolore aliquid fugiat aliquam. Molestias repellat ab sed."
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h3", { className: "text-2xl font-semibold", children: "Amenities" }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-x-12  rounded-2xl my-5 md:flex-row flex-col px-4 md:px-0", children: [
              /* @__PURE__ */ jsx(Amenity, { icon1: faCamera, icon2: faDumbbell, icon3: faBed, title1: "Security", title2: "Gym", title3: "Furnished" }),
              /* @__PURE__ */ jsx(Amenity, { icon1: faCamera, icon2: faDumbbell, icon3: faBed, title1: "Security", title2: "Gym", title3: "Furnished" }),
              /* @__PURE__ */ jsx(Amenity, { icon1: faCamera, icon2: faDumbbell, icon3: faBed, title1: "Security", title2: "Gym", title3: "Furnished" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "outline outline-1 rounded-lg outline-gray-500 p-5 md:w-[45%] ", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-2xl font-semibold mb-2", children: "Book it" }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", className: "p-2", children: "Full Name" }),
            /* @__PURE__ */ jsx("input", { type: "text", name: "", id: "", className: "md:w-[300px] mx-3 focus:ring-0 ring-gray-500", placeholder: "Enter your name" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1 py-1", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", className: "p-2", children: "Email Address" }),
            /* @__PURE__ */ jsx("input", { type: "text", name: "", id: "", className: "md:w-[300px] mx-3 focus:ring-0 ring-gray-500", placeholder: "Enter email" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1 py-1", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", className: "p-2", children: "Message" }),
            /* @__PURE__ */ jsx("textarea", { type: "text", name: "", id: "", className: "md:w-[400px] h-[200px] mx-3 focus:ring-0 ring-gray-500", placeholder: "Enter message" })
          ] }),
          /* @__PURE__ */ jsx("button", { type: "submit", className: "px-5 py-3 text-white bg-greenish my-4 mx-4", children: "Book" })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx(GetTheApp, { googleBadge: "images/google-play-badge.png", iphoneBadge: "images/google-play-badge.png", img: "images/phone-mpckup.png" }),
      /* @__PURE__ */ jsx(MyFooter, { youWant: true, bgColor: "mt-10" })
    ] })
  ] });
}
export {
  MallDetail as default
};
