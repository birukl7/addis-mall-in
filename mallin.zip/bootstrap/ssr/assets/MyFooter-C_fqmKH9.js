import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import "react";
import { S as SocialIcon } from "./Header-COyX0vDs.js";
import { faTelegram, faInstagram, faTwitter, faFacebookF } from "@fortawesome/free-brands-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeadset, faArrowRight, faRocket, faLocation, faPhone, faMailBulk } from "@fortawesome/free-solid-svg-icons";
function FooterCard({ title }) {
  return /* @__PURE__ */ jsxs("div", { className: "py-4", children: [
    /* @__PURE__ */ jsx("h4", { className: "text-2xl py-2 font-semibold", children: title }),
    /* @__PURE__ */ jsxs("ul", { className: "pl-3 md:pl-0", children: [
      /* @__PURE__ */ jsxs("li", { children: [
        " ",
        /* @__PURE__ */ jsx("a", { href: "#", className: "hover:underline", children: "Home" })
      ] }),
      /* @__PURE__ */ jsxs("li", { children: [
        " ",
        /* @__PURE__ */ jsx("a", { href: "#", className: "hover:underline", children: "Accomodation" })
      ] }),
      /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx("a", { href: "#", className: "hover:underline", children: "Gallery" }),
        " "
      ] }),
      /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx("a", { href: "#", className: "hover:underline", children: "Blog" }),
        " "
      ] }),
      /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx("a", { href: "#", className: "hover:underline", children: "Contact" }),
        " "
      ] })
    ] })
  ] });
}
function MyFooter({ bgColor, youWant }) {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("section", { className: ` ${bgColor} `, children: [
    /* @__PURE__ */ jsx("div", { className: `${youWant ? "" : "hidden"} max-w-[1100px] mx-auto py-10 px-5`, children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between gap-x-[50px] md:flex-row flex-col gap-y-5", children: [
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center max-w-[400px] gap-x-6 outline outline-1 outline-slate-500 p-5 rounded-xl", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faHeadset, className: "text-5xl text-greenish" }),
        /* @__PURE__ */ jsx("p", { className: "md:text-2xl ", children: "Need Any Suppport For Tour & Travles ?" }),
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "text-xl ml-5 -rotate-45" })
      ] }) }),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center max-w-[420px] gap-x-6 outline outline-1 outline-slate-500 p-5 rounded-xl", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faRocket, className: "text-5xl text-greenish" }),
        /* @__PURE__ */ jsx("p", { className: "md:text-2xl ", children: "Ready to Get Started With Vacations!" }),
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "text-xl ml-5 -rotate-45" })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxs("footer", { className: `max-w-[1200px] mx-auto px-5`, children: [
      /* @__PURE__ */ jsxs("div", { className: " grid md:grid-cols-4 sm:grid-cols-3 gap-x-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("h1", { className: "text-3xl font-semibold", children: "Mall In" }) }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("p", { className: "py-2 md:w-[200px] w-[350px]", children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit, nisi?. Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, eligendi." }) }),
          /* @__PURE__ */ jsxs("div", { className: "md:py-2 py-5", children: [
            /* @__PURE__ */ jsx(SocialIcon, { icon: faTelegram }),
            /* @__PURE__ */ jsx(SocialIcon, { icon: faInstagram }),
            /* @__PURE__ */ jsx(SocialIcon, { icon: faTwitter }),
            /* @__PURE__ */ jsx(SocialIcon, { icon: faFacebookF })
          ] })
        ] }),
        /* @__PURE__ */ jsx(FooterCard, { title: "Quick Links" }),
        /* @__PURE__ */ jsx(FooterCard, { title: "About Us" }),
        /* @__PURE__ */ jsxs("div", { className: "pt-4", children: [
          /* @__PURE__ */ jsx("h4", { className: "text-2xl py-2 font-semibold ", children: "Contact Us" }),
          /* @__PURE__ */ jsxs("ul", { children: [
            /* @__PURE__ */ jsxs("li", { className: "gap-x-3 flex items-center py-1", children: [
              /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faLocation }),
              " ",
              /* @__PURE__ */ jsx("address", { children: "Addis Ababa, Sealite Mihret" })
            ] }),
            /* @__PURE__ */ jsxs("li", { className: "gap-x-3 flex items-center py-1", children: [
              " ",
              /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faPhone }),
              /* @__PURE__ */ jsx("a", { href: "tel", children: "+251-11-1111-11" })
            ] }),
            /* @__PURE__ */ jsxs("li", { className: "gap-x-3 flex items-center py-1", children: [
              /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faMailBulk }),
              /* @__PURE__ */ jsx("a", { href: "mailto", children: "melfantech@info.com" })
            ] }),
            /* @__PURE__ */ jsx("li", {})
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "py-5 border-t-2 mt-3 flex justify-center items-center", children: [
        "copyright@",
        /* @__PURE__ */ jsx("span", { className: "text-yellowish", children: "Melfan Tech" }),
        "  by  ",
        /* @__PURE__ */ jsx("a", { href: "https://biruk-lemma.vercel.com", className: "underline", children: "Biruk Lemma" }),
        "  2024"
      ] })
    ] })
  ] }) });
}
export {
  MyFooter as M
};
