import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { H as Header } from "./Header-COyX0vDs.js";
import { S as Selector } from "./Selector-DjJJhMdL.js";
import { faLocation, faDirections, faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "react";
import { a as addis } from "./addis-DShJIjJE.js";
import { G as GetTheApp } from "./GetTheApp-BwTlhFun.js";
import { g as google, r as rust$1 } from "./phone-mpckup-D1gSHcVV.js";
import { M as MyFooter } from "./MyFooter-C_fqmKH9.js";
import { usePage } from "@inertiajs/react";
import "@fortawesome/free-brands-svg-icons";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "react-icons/bi";
import "react-icons/ai";
function JobCard({ image }) {
  return /* @__PURE__ */ jsxs("div", { className: "flex gap-x-3 bg-gray-100 p-3 rounded-lg my-5 outline outline-1 pt-6", children: [
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("img", { src: image, alt: "", className: "w-16" }) }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xl font-semibold", children: "Junior UI/UX Designer" }),
      /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Slack Technologies, LLC" }),
      /* @__PURE__ */ jsx("p", { className: " line-clamp-3 py-2 max-w-[500px]", children: "We are lookin for a young ralented designer to help us to create stunnig websites and apps. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, officiis? Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aperiam, necessitatibus." }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2 p-3 outline outline-1 rounded-lg mb-4 mt-3 hover:bg-greenish hover:text-white cursor-pointer transition-all ease-in-out duration-150", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faLocation, className: "" }),
        /* @__PURE__ */ jsx("span", { className: "underline", children: "Edna mall" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2 p-3 outline outline-1 rounded-lg hover:bg-yellowish hover:text-white cursor-pointer transition-all duration-100 ease-out", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faDirections, className: "" }),
        /* @__PURE__ */ jsx("span", { className: "", children: "Directions" }),
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: " -rotate-45 hover:rotate-0 transition-all duration-200 ease-in-out hover:cursor-pointer" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-x-4 gap-y-3 mt-4", children: [
        /* @__PURE__ */ jsx("button", { className: "bg-gray-200 text-xs p-2 py-1 rounded-full", children: "Full Time" }),
        /* @__PURE__ */ jsx("button", { className: "bg-gray-200 text-xs p-2 py-1 rounded-full", children: "Laravel" })
      ] })
    ] })
  ] });
}
const rust = "https://addismall.biruklemma.com/build/assets/pp2-DlLXK-uw.jpg";
function JobGrid({ height }) {
  return /* @__PURE__ */ jsxs("div", { style: { backgroundImage: `url('${addis}')` }, className: `h-[${height}] bg-center bg-cover rounded-xl text-white p-5 relative`, children: [
    /* @__PURE__ */ jsx("p", { className: "text-xl ", children: "Century Mall" }),
    /* @__PURE__ */ jsxs("div", { className: "flex absolute items-center justify-between bottom-0  right-0 left-0 p-5 px-8", children: [
      /* @__PURE__ */ jsxs("p", { className: "flex flex-col text-xs", children: [
        /* @__PURE__ */ jsx("span", { children: "5+ Vacancy" }),
        /* @__PURE__ */ jsx("span", { children: "6+ Free Spaces" })
      ] }),
      /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "-rotate-45 hover:rotate-0 transition-all duration-100 ease-linear hover:cursor-pointer" })
    ] })
  ] });
}
function Space() {
  const { envVariables } = usePage().props;
  const toggleMenu = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.toggle("hidden");
  };
  const toggleMenuClose = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.add("hidden");
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Header, { func1: toggleMenu, onclick: toggleMenuClose }),
    /* @__PURE__ */ jsxs("main", { onClick: toggleMenuClose, children: [
      /* @__PURE__ */ jsx("section", { className: "mt-10", children: /* @__PURE__ */ jsxs("div", { className: "max-w-[1100px] mx-auto  rounded-lg bg-yellowish text-white p-10 outline oultline-black outline-2", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-3xl font-semibold", children: "Looking for a new Opportunitits in malls?" }),
        /* @__PURE__ */ jsx("p", { className: "py-3", children: "Browse our latest job openings" })
      ] }) }),
      /* @__PURE__ */ jsx("section", { className: "max-w-[1200px] mx-auto mt-7", children: /* @__PURE__ */ jsxs("div", { className: "gap-y-3 md:gap-y-0 grid md:grid-cols-4 sm:grid-cols-3  gap-x-8 p-6 bg-white shadow-2xl rounded-lg", children: [
        /* @__PURE__ */ jsx(Selector, { title: "Location", api: "addis-ababa-locations", url: envVariables.APP_URL }),
        /* @__PURE__ */ jsx(Selector, { title: "Job Type", api: "job-type", url: envVariables.APP_URL }),
        /* @__PURE__ */ jsx(Selector, { title: "Experience", api: "job-experience", url: envVariables.APP_URL }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("button", { type: "submit", className: "bg-greenish text-white py-3 px-5 flex items-center justify-center mt-7 rounded-xl", children: "Apply Filter" }) })
      ] }) }),
      /* @__PURE__ */ jsxs("section", { className: "flex md:flex-row flex-col max-w-[1300px] mx-auto mt-10 gap-x-8 px-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("h2", { className: "text-2xl font-semibold pb-5", children: "Related Jobs" }) }),
          /* @__PURE__ */ jsx(JobCard, { image: rust }),
          /* @__PURE__ */ jsx(JobCard, { image: rust }),
          /* @__PURE__ */ jsx(JobCard, { image: rust }),
          /* @__PURE__ */ jsx(JobCard, { image: rust }),
          /* @__PURE__ */ jsx(JobCard, { image: rust }),
          /* @__PURE__ */ jsx("div", { className: "flex text-center w-full items-center justify-center py-3 outline outline-1 hover:bg-greenish hover:text-white", children: "Show More" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
          /* @__PURE__ */ jsx("h3", { className: "text-2xl m-2 font-semibold pb-6", children: "Malls With Vacancies/Free space" }),
          /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-2 gap-x-5", children: [
            /* @__PURE__ */ jsxs("div", { className: "grid gap-y-5", children: [
              /* @__PURE__ */ jsx(JobGrid, { height: "400px" }),
              /* @__PURE__ */ jsx(JobGrid, { height: "300px" }),
              /* @__PURE__ */ jsx(JobGrid, { height: "300px" }),
              /* @__PURE__ */ jsx(JobGrid, { height: "400px" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid gap-y-5", children: [
              /* @__PURE__ */ jsx(JobGrid, { height: "300px" }),
              /* @__PURE__ */ jsx(JobGrid, { height: "400px" }),
              /* @__PURE__ */ jsx(JobGrid, { height: "400px" }),
              /* @__PURE__ */ jsx(JobGrid, { height: "300px" })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx(GetTheApp, { googleBadge: google, iphoneBadge: google, img: rust$1 }),
      /* @__PURE__ */ jsx("section", { className: "mt-20", children: /* @__PURE__ */ jsx(MyFooter, {}) })
    ] })
  ] });
}
export {
  Space as default
};
