import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { H as Header } from "./Header-COyX0vDs.js";
import "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMailBulk, faPhone } from "@fortawesome/free-solid-svg-icons";
import { M as MyFooter } from "./MyFooter-C_fqmKH9.js";
import { G as GetTheApp } from "./GetTheApp-BwTlhFun.js";
import { g as google, r as rust } from "./phone-mpckup-D1gSHcVV.js";
import "@fortawesome/free-brands-svg-icons";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "@inertiajs/react";
const contactImg = "https://addismall.biruklemma.com/build/assets/Contact%20us-amico-Blk-63cz.svg";
function Contact() {
  const toggleMenu = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.toggle("hidden");
  };
  const toggleMenuClose = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.add("hidden");
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Header, { func1: toggleMenu, onclick: toggleMenuClose }),
    /* @__PURE__ */ jsxs("main", { onClick: toggleMenuClose, children: [
      /* @__PURE__ */ jsxs("section", { className: "flex max-w-[1400px] mx-auto mt-16  items-center flex-col md:flex-row gap-x-[100px] px-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "md:w-[40%]", children: [
          /* @__PURE__ */ jsx("span", { className: "text-yellowish text-xl", children: "Get in Touch" }),
          /* @__PURE__ */ jsx("h1", { className: "text-4xl font-semibold py-3", children: "Let's Chat, Reach Out to Us" }),
          /* @__PURE__ */ jsx("p", { className: "max-w-[400px] pb-10 border-b", children: "Have questions or feedback? We're here to help. Send us a message, and we'll respond within 24 hours" }),
          /* @__PURE__ */ jsxs("div", { className: "flex md:flex-row pt-10 justify-between flex-col", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsx("label", { htmlFor: "", className: "font-semibold py-2", children: "First Name" }),
              /* @__PURE__ */ jsx("input", { type: "text", name: "", id: "", className: "", placeholder: "First name" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col pt-3 md:pt-0", children: [
              /* @__PURE__ */ jsx("label", { htmlFor: "", className: "font-semibold py-2", children: "Last Name" }),
              /* @__PURE__ */ jsx("input", { type: "text", name: "", id: "", placeholder: "Last name" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col pt-5", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", className: "font-semibold py-2", children: "Email" }),
            /* @__PURE__ */ jsx("input", { type: "text", name: "", id: "", className: "mx-1", placeholder: "Email address" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col pt-5", children: [
            /* @__PURE__ */ jsx("label", { htmlFor: "", className: "font-semibold py-2", children: "Message" }),
            /* @__PURE__ */ jsx("textarea", { type: "text", name: "", id: "", className: "h-[200px]" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "py-4", children: [
            /* @__PURE__ */ jsx("input", { type: "checkbox", name: "", id: "" }),
            /* @__PURE__ */ jsxs("label", { htmlFor: "", children: [
              "  I agree to our friendly ",
              /* @__PURE__ */ jsx("a", { href: "#", className: "underline", children: "privacy policy" })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("button", { className: "px-3 py-3 bg-greenish text-white", children: "Submit" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "md:w-[40%]", children: [
          /* @__PURE__ */ jsx("div", { className: "w-full ", children: /* @__PURE__ */ jsx("img", { src: contactImg, alt: "" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-4", children: [
              /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faMailBulk, className: "p-4 text-greenish text-xl outline outline-1 rounded-full " }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col ", children: [
                /* @__PURE__ */ jsx("div", { className: "font-semibold text-xl", children: "Email" }),
                /* @__PURE__ */ jsx("div", { children: "melfantech@gmail.com" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-4 py-10", children: [
              /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faPhone, className: "p-4 text-greenish text-xl outline outline-1 rounded-full " }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col ", children: [
                /* @__PURE__ */ jsx("div", { className: "font-semibold text-xl", children: "Phone" }),
                /* @__PURE__ */ jsx("div", { children: "+251-94-405-5361" })
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx(GetTheApp, { googleBadge: google, iphoneBadge: google, img: rust }),
      /* @__PURE__ */ jsx("section", { className: "py-10 max-w-[1300px] mx-auto", children: /* @__PURE__ */ jsx("iframe", { src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.5233533434284!2d38.821460175872765!3d9.01592988919165!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164b8506561640e7%3A0xdb3e17edac66bcd3!2sMelfan%20tech!5e0!3m2!1sen!2set!4v1716662214077!5m2!1sen!2set", loading: "lazy", referrerpolicy: "no-referrer-when-downgrade", className: "w-full h-[350px]" }) }),
      /* @__PURE__ */ jsx(MyFooter, {})
    ] })
  ] });
}
export {
  Contact as default
};
