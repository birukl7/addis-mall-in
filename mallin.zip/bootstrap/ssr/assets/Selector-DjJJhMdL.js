import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { BiChevronDown } from "react-icons/bi";
import { AiOutlineSearch } from "react-icons/ai";
import "@inertiajs/react";
const Selector = ({ title, api, url }) => {
  const [countries, setCountries] = useState(null);
  const [inputValue, setInputValue] = useState("");
  const [selected, setSelected] = useState("");
  const [open, setOpen] = useState(false);
  useEffect(() => {
    fetch(`${url}/api/${api}`).then((res) => res.json()).then((data) => {
      setCountries(data);
    });
  }, [api]);
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3", children: [
    /* @__PURE__ */ jsx("span", { children: title }),
    /* @__PURE__ */ jsxs("div", { className: "relative font-medium h-8 ", children: [
      /* @__PURE__ */ jsxs(
        "div",
        {
          onClick: () => setOpen(!open),
          className: `bg-white w-full p-2 flex items-center justify-between rounded-full ring-1 ring-gray-300 focus:ring-gray-400 px-3 cursor-pointer ${!selected && "text-gray-700"}`,
          children: [
            selected ? selected.length > 25 ? selected.substring(0, 25) + "..." : selected : `Select ${title}`,
            /* @__PURE__ */ jsx(BiChevronDown, { size: 20, className: `${open && "rotate-180"}` })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        "ul",
        {
          className: `bg-white mt-2 overflow-y-auto relative w-full left-0 z-40 transition-max-height duration-300 ${open ? "max-h-60" : "max-h-0"}`,
          style: { position: "absolute" },
          children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center px-2 sticky top-0 bg-white", children: [
              /* @__PURE__ */ jsx(AiOutlineSearch, { size: 18, className: "text-gray-700" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  value: inputValue,
                  onChange: (e) => setInputValue(e.target.value.toLowerCase()),
                  placeholder: `Enter ${title}`,
                  className: "placeholder:text-gray-700 p-2 outline-none w-full ring-gray-300 focus:ring-0 ring-0 border-0 text-xs"
                }
              )
            ] }),
            countries == null ? void 0 : countries.map((country) => {
              var _a, _b;
              return /* @__PURE__ */ jsx(
                "li",
                {
                  className: `p-2 text-sm hover:bg-sky-600 hover:text-white cursor-pointer ${((_a = country == null ? void 0 : country.name) == null ? void 0 : _a.toLowerCase()) === (selected == null ? void 0 : selected.toLowerCase()) && "bg-sky-600 text-white"} ${((_b = country == null ? void 0 : country.name) == null ? void 0 : _b.toLowerCase().startsWith(inputValue)) ? "block" : "hidden"}`,
                  onClick: () => {
                    var _a2;
                    if (((_a2 = country == null ? void 0 : country.name) == null ? void 0 : _a2.toLowerCase()) !== selected.toLowerCase()) {
                      setSelected(country == null ? void 0 : country.name);
                      setOpen(false);
                      setInputValue("");
                    }
                  },
                  children: country == null ? void 0 : country.name
                },
                country == null ? void 0 : country.name
              );
            })
          ]
        }
      )
    ] })
  ] });
};
export {
  Selector as S
};
