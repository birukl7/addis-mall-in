import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { faClock, faMagnifyingGlass, faBookmark, faListDots } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "react";
import { G as GetTheApp } from "./GetTheApp-BwTlhFun.js";
import { H as Header } from "./Header-COyX0vDs.js";
import { M as MyFooter } from "./MyFooter-C_fqmKH9.js";
import "flowbite-react";
import { g as google, r as rust } from "./phone-mpckup-D1gSHcVV.js";
import "@fortawesome/free-brands-svg-icons";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "@inertiajs/react";
const pp = "https://addismall.biruklemma.com/build/assets/pp1-BCQdIgzC.jpg";
function AsideBlogCard() {
  return /* @__PURE__ */ jsxs("div", { className: "flex gap-x-3 rounded-xl overflow-hidden border-t pt-4 border-b", children: [
    /* @__PURE__ */ jsx("div", { style: { backgroundImage: `url('${pp}')` }, className: "w-[50%] h-[80px] rounded-xl bg-cover bg-center" }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("p", { className: " line-clamp-3 font-semibold pb-", children: "Stop using old-fashioned closures in modern PHP. There are 4* ways to replace them." }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs py-3 flex items-center gap-x-3", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faClock, className: "text-greenish" }),
        /* @__PURE__ */ jsx("span", { children: "Jan 05, 2024" })
      ] })
    ] })
  ] });
}
function AsideBar() {
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("h2", { className: "text-2xl py-4 font-semibold", children: "Search Blogs" }),
    /* @__PURE__ */ jsxs("div", { className: "", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faMagnifyingGlass, className: "p-3 border-l border-t border-b border-slate-400" }),
        /* @__PURE__ */ jsx("input", { type: "search", name: "", id: "", className: "w-full" }),
        /* @__PURE__ */ jsx("button", { className: "bg-yellowish px-3 text-white ", children: "Search" })
      ] }),
      /* @__PURE__ */ jsx("h3", { className: "py-4 text-xl font-semibold", children: "Latest Posts" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(AsideBlogCard, {}),
        /* @__PURE__ */ jsx(AsideBlogCard, {}),
        /* @__PURE__ */ jsx(AsideBlogCard, {}),
        /* @__PURE__ */ jsx(AsideBlogCard, {}),
        /* @__PURE__ */ jsx(AsideBlogCard, {})
      ] })
    ] })
  ] });
}
const dog = "https://addismall.biruklemma.com/build/assets/dogpp-BJextnkc.jpg";
function BlogContain() {
  return /* @__PURE__ */ jsxs("div", { className: " border-b-[0.25px] border-slate-400 pb-2 pt-5", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-4 py-3", children: [
      /* @__PURE__ */ jsx("div", { className: "w-[30px] h-[30px] rounded-full bg-center bg-cover", style: { backgroundImage: `url('${dog}')` } }),
      /* @__PURE__ */ jsx("p", { children: "Hazel Pradise 	· Mar 27, 2024" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { className: "text-xl font-semibold mb-[100px]", children: "How I Create Passive Income With No Money" }),
        /* @__PURE__ */ jsx("p", { className: " line-clamp-3 w-full pt-3", children: "Many ways to start a passive income today - ALways, always start with ZERO money. You won't regret it! I never loved the idea of working 9-5 and receiving money at the end of the month. Well, I used to receive i Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam, repellendus soluta illo corrupti at numquam esse sint animi excepturi ipsum quaerat, molestiae consequatur neque optio ab quae, autem dolores assumenda. Obcaecati corporis voluptatum, quasi recusandae illum cum maiores beatae rem voluptatem sequi ipsum quidem debitis maxime fuga reprehenderit laudantium atque amet quam, magni eum odit temporibus sunt. Deserunt, magnam in excepturi, quos eveniet earum officiis tempore impedit rem facere aspernatur. Facilis in similique ab error nihil possimus nobis soluta maiores eius voluptatum incidunt, voluptatem inventore dolor laborum temporibus beatae placeat expedita ad ipsam. Sapiente, esse? Autem at quibusdam eveniet! Dolorum. " })
      ] }),
      /* @__PURE__ */ jsx("div", { style: { backgroundImage: `url('${dog}')` }, className: "md:w-[300%] w-[900%] ml-10 h-[130px] bg-center bg-cover" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between py-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-3", children: [
        /* @__PURE__ */ jsx("span", { className: "bg-slate-400 p-2 rounded-full text-xs font-semibold px-3", children: "Passive Income" }),
        /* @__PURE__ */ jsx("span", { className: "text-slate-600", children: "5 min read" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-3 mr-[15px]", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faBookmark, className: "text-greenish p-3" }),
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faListDots, className: "text-greenish p-3" })
      ] })
    ] })
  ] });
}
function Blog() {
  const toggleMenu = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.toggle("hidden");
  };
  const toggleMenuClose = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.add("hidden");
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Header, { func1: toggleMenu, onclick: toggleMenuClose }),
    /* @__PURE__ */ jsxs("main", { onClick: toggleMenuClose, children: [
      /* @__PURE__ */ jsxs("section", { className: "flex max-w-[1100px] mx-auto pt-10 gap-x-[8%] flex-col md:flex-row px-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "md:w-[63%]", children: [
          /* @__PURE__ */ jsx(BlogContain, {}),
          /* @__PURE__ */ jsx(BlogContain, {}),
          /* @__PURE__ */ jsx(BlogContain, {}),
          /* @__PURE__ */ jsx(BlogContain, {}),
          /* @__PURE__ */ jsx(BlogContain, {}),
          /* @__PURE__ */ jsx(BlogContain, {}),
          /* @__PURE__ */ jsx("div", { className: "py-7", children: /* @__PURE__ */ jsx("button", { className: "w-full border border-black py-3 rounded-xl font-semibold hover:bg-yellowish hover:text-white hover:border-white transition-all duration-150 ", children: "Show More" }) })
        ] }),
        /* @__PURE__ */ jsx("aside", { className: "md:w-[32%]", children: /* @__PURE__ */ jsx(AsideBar, {}) })
      ] }),
      /* @__PURE__ */ jsx(GetTheApp, { googleBadge: google, iphoneBadge: google, img: rust }),
      /* @__PURE__ */ jsx(MyFooter, { bgColor: " pt-8", youWant: true })
    ] })
  ] });
}
export {
  Blog as default
};
