import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { faShoppingCart, faMagnifyingGlass, faThumbsUp, faArrowLeft, faArrowRight, faShield, faUniversity } from "@fortawesome/free-solid-svg-icons";
import { faTelegram } from "@fortawesome/free-brands-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { H as Header, D as Ddrop } from "./Header-COyX0vDs.js";
import { F as FIlterContainer, M as MallCard } from "./FIlterContainer-B3Xj9lfK.js";
import { a as addis } from "./addis-DShJIjJE.js";
import { g as google, r as rust } from "./phone-mpckup-D1gSHcVV.js";
import CountUp from "react-countup";
import ScrollTrigger from "react-scroll-trigger";
import { G as GetTheApp } from "./GetTheApp-BwTlhFun.js";
import { M as MyFooter } from "./MyFooter-C_fqmKH9.js";
import { useInView } from "react-intersection-observer";
import { usePage } from "@inertiajs/react";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "./Selector-DjJJhMdL.js";
import "react-icons/bi";
import "react-icons/ai";
const mallimage = "https://addismall.biruklemma.com/build/assets/mall-9-CuxQgYPp.jpg";
const illust = "https://addismall.biruklemma.com/build/assets/Online%20shopping-amico-CXmYtS4q.svg";
const rating1 = "https://addismall.biruklemma.com/build/assets/rating-0-CZPz6W-2.png";
const rating05 = "https://addismall.biruklemma.com/build/assets/rating-05-BwgNL5cU.png";
function Numbers() {
  const [counterState, setCounterState] = useState(false);
  return /* @__PURE__ */ jsx(ScrollTrigger, { onEnter: () => setCounterState(true), onExit: () => setCounterState(false), children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row justify-between md:py-10 ", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center  py-4 md:py-0 md:border-r-2 border-r-black px-16 max-w-[150px] ml-20 md:ml-0", children: [
      /* @__PURE__ */ jsxs("span", { className: "text-5xl text-greenish", children: [
        counterState && /* @__PURE__ */ jsx(CountUp, { start: 0, end: 200, duration: 3 }),
        "+"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-x-2 items-center", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faShoppingCart, className: "text-greenish" }),
        /* @__PURE__ */ jsx("span", { className: "text-xl", children: "Malls" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center  py-4 md:py-0 md:border-r-2 border-r-black px-16 max-w-[150px] md:pr-28 ml-20 md:ml-0", children: [
      /* @__PURE__ */ jsxs("span", { className: "text-5xl text-greenish", children: [
        counterState && /* @__PURE__ */ jsx(CountUp, { start: 0, end: 80, duration: 3 }),
        "+"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-x-2 items-center", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faShoppingCart, className: "text-greenish" }),
        /* @__PURE__ */ jsx("span", { className: "text-xl", children: "Partners" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center  py-4 md:py-0 md:border-r-2 border-r-black px-16 max-w-[150px] md:pr-28 ml-20 md:ml-0", children: [
      /* @__PURE__ */ jsxs("span", { className: "text-5xl text-greenish", children: [
        counterState && /* @__PURE__ */ jsx(CountUp, { start: 0, end: 2e3, duration: 3 }),
        "+"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-x-2 items-center", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faShoppingCart, className: "text-greenish" }),
        /* @__PURE__ */ jsx("span", { className: "text-xl", children: "Shops" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center py-4 md:py-0  md:border-r-2 border-r-black px-16 max-w-[150px] md:pr-28 ml-20 md:ml-0", children: [
      /* @__PURE__ */ jsxs("span", { className: "text-5xl text-greenish", children: [
        counterState && /* @__PURE__ */ jsx(CountUp, { start: 0, end: 3400, duration: 3 }),
        "+"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-x-2 items-center", children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faMagnifyingGlass, className: "text-greenish" }),
        /* @__PURE__ */ jsx("span", { className: "text-xl", children: "Searchs" })
      ] })
    ] })
  ] }) });
}
function ArticleCard() {
  return /* @__PURE__ */ jsxs("div", { className: "shadow-2xl rounded-xl hover:-translate-y-3 transition-all duration-200 ease-in-out", children: [
    /* @__PURE__ */ jsx("div", { className: "rounded-xl overflow-hidden", children: /* @__PURE__ */ jsx("img", { src: addis, alt: "" }) }),
    /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "py-2", children: [
        /* @__PURE__ */ jsx("span", { className: "px-4 text-slate-500 underline", children: "FOOD" }),
        /* @__PURE__ */ jsx("span", { className: " text-slate-500 underline", children: "ADDIS" })
      ] }),
      /* @__PURE__ */ jsx("a", { href: "/blogs", children: /* @__PURE__ */ jsx("p", { className: "px-7 max-w-[300px] font-semibold", children: "The 8 Most Affordable Shops in Addis Ababa." }) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "px-8 pb-5 flex gap-x-10", children: /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-x-2", children: [
      /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faThumbsUp, className: "text-slate-600" }),
      /* @__PURE__ */ jsx("span", { children: "2" })
    ] }) })
  ] });
}
function FIndMalls({ icon, title, description }) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-5 pt-8", children: [
    /* @__PURE__ */ jsx(FontAwesomeIcon, { icon, className: "md:text-3xl text-2xl text-yellowish" }),
    /* @__PURE__ */ jsxs("p", { className: "", children: [
      /* @__PURE__ */ jsx("span", { className: "md:text-3xl text-2xl font-semibold ", children: title }),
      " ",
      /* @__PURE__ */ jsx("br", {}),
      description
    ] })
  ] });
}
function Welcome({ auth, laravelVersion, phpVersion }) {
  useInView();
  const { envVariables } = usePage().props;
  console.log(envVariables.APP_URL);
  const toggleMenu = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.toggle("hidden");
  };
  const toggleMenuClose = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.add("hidden");
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Header, { func1: toggleMenu, onclick: toggleMenuClose }),
    /* @__PURE__ */ jsxs("main", { onClick: toggleMenuClose, children: [
      /* @__PURE__ */ jsxs(
        "section",
        {
          style: { backgroundImage: `url('${mallimage}')` },
          className: "text-white h-[500px] flex justify-center items-center bg-cover bg-center -mt-6 px-5 md:px-0 relative -z-10",
          children: [
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent rounded-xl" }),
            /* @__PURE__ */ jsx("div", { className: "flex justify-center items-center", children: /* @__PURE__ */ jsx("h1", { className: "text-7xl font-bold", children: "Explore Malls in Addis" }) })
          ]
        }
      ),
      /* @__PURE__ */ jsx("section", { className: "max-w-[1200px] w-full mx-auto  items-center justify-center px-5", children: /* @__PURE__ */ jsx(FIlterContainer, { url: envVariables.APP_URL }) }),
      /* @__PURE__ */ jsxs("section", { className: "max-w-[1200px] mx-auto mt-12 mb-4 px-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center mb-5", children: [
          /* @__PURE__ */ jsx("h2", { className: "font-bold", children: "Showing Resullts " }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("strong", { children: "Sort By      " }),
            /* @__PURE__ */ jsx(Ddrop, {})
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-5", children: [
          /* @__PURE__ */ jsx(MallCard, { rating: rating1, num: 1, img: "images/mall-6.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 2, img: "images/mall-3.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, img: "images/mall-2.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating1, num: 1, img: "images/mall-4.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 4, img: "images/mall-7.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, img: "images/mall-8.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating1, num: 1, img: "images/mall-9.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 6, img: "images/mall-6.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 7, img: "images/mall-4.jpg" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center py-2 justify-center mt-20 gap-x-3 text-xs", children: [
          /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowLeft, className: "p-1 outline-1 outline-slate-600  outline rounded-full" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full bg-greenish text-white cursor-pointer", children: "01" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full hover:bg-greenish hover:text-white cursor-pointer", children: "02" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full hover:bg-greenish hover:text-white cursor-pointer", children: "03" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full hover:bg-greenish hover:text-white cursor-pointer", children: "04" }),
          /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "p-1 outline-1 outline-slate-600  outline rounded-full" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("section", { className: "max-w-[1100px] w-full mx-auto  mt-10 mb-10 px-4", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-between items-center mb-5", children: /* @__PURE__ */ jsx("h2", { className: "font-bold text-2xl", children: "Popular Subctites " }) }),
        /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-2 grid-cols-1 gap-x-5 gap-y-6 md:gap-y-0", children: [
          /* @__PURE__ */ jsxs("div", { style: { backgroundImage: 'url("images/mall-7.jpg")' }, className: "rounded-xl md:h-[600px]  bg-cover relative", children: [
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent rounded-xl" }),
            /* @__PURE__ */ jsxs("div", { className: " flex  items-center text-white justify-between px-4 pr-8 mt-[490px] ", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col p-5 z-20", children: [
                /* @__PURE__ */ jsx("h3", { className: "text-3xl x", children: "Yeka Subcity" }),
                /* @__PURE__ */ jsx("span", { children: "3+ Listing" })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "p-3 rounded-full outline outline-1 z-20", children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "text-white text-xl" }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-y-5", children: [
            /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-2 grid-cols-1 gap-x-5 gap-y-6 md:gap-y-0", children: [
              /* @__PURE__ */ jsxs("div", { className: "bg-cover bg-center rounded-xl  h-[300px] md:h-auto relative", style: { backgroundImage: `url('${addis}')` }, children: [
                /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent rounded-xl" }),
                /* @__PURE__ */ jsxs("div", { className: " flex  items-center text-white justify-center absolute bottom-0", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex flex-col p-5", children: [
                    /* @__PURE__ */ jsx("h3", { className: "text-xl", children: "Yeka Subcity" }),
                    /* @__PURE__ */ jsx("span", { children: "3+ Listing" })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "p-[1.5px] rounded-full  ", children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "text-white text-[14px]" }) })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "bg-cover bg-center rounded-xl relative h-[300px] md:h-auto", style: { backgroundImage: `url('${addis}')` }, children: [
                /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent rounded-xl" }),
                /* @__PURE__ */ jsxs("div", { className: " flex  items-center text-white justify-between px-4 pr-8 absolute bottom-0", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex flex-col p-5", children: [
                    /* @__PURE__ */ jsx("h3", { className: "text-xl", children: "Yeka Subcity" }),
                    /* @__PURE__ */ jsx("span", { children: "3+ Listing" })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "p-3 rounded-full ", children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "text-white" }) })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "rounded-xl bg-center bg-cover relative h-[400px] md:h-auto", style: { backgroundImage: `url('${addis}')` }, children: [
              /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent rounded-xl" }),
              /* @__PURE__ */ jsxs("div", { className: "flex md:gap-x-[230px] items-center text-white justify-between px-4 md:pr-8 absolute bottom-0", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col p-5", children: [
                  /* @__PURE__ */ jsx("h3", { className: "text-3xl", children: "Yeka Subcity" }),
                  /* @__PURE__ */ jsx("span", { children: "3+ Listing" })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "p-3 rounded-full outline outline-1 ", children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "text-white text-xl" }) })
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("section", { className: " max-w-[1200px] mx-auto px-4", children: /* @__PURE__ */ jsx(Numbers, {}) }),
      /* @__PURE__ */ jsx("section", { className: "max-w-[1200px] mx-auto pt-14 md:pt-10 h-screen flex items-center px-5 ", children: /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-2 justify-between ", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsx("h2", { className: "md:text-6xl text-5xl text-center md:text-left ", children: "Find your malls in addis" }),
          /* @__PURE__ */ jsx(FIndMalls, { icon: faMagnifyingGlass, title: "Define Your Needs", description: "Consider the type of shopping experience you prefer, such as high-end fashion, electronics, home goods, or a combination." }),
          /* @__PURE__ */ jsx(FIndMalls, { icon: faShield, title: "Utilize Search Tools", description: `Perform searches using keywords related to your preferences, such as "Technology", "Fashion" or "Bank".` }),
          /* @__PURE__ */ jsx(FIndMalls, { icon: faUniversity, title: "Visit Mall Details", description: "                Visit the malls detail information on the platform that showcase their offerings, list of stores, events, and others." })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "px-3 pt-5 md:p-0", children: /* @__PURE__ */ jsx("img", { src: illust, alt: "shopping", className: "" }) })
      ] }) }),
      /* @__PURE__ */ jsx(GetTheApp, { googleBadge: google, iphoneBadge: google, img: rust }),
      /* @__PURE__ */ jsx("section", { className: "pt-10 px-5 ", children: /* @__PURE__ */ jsxs("div", { className: "max-w-[1200px] mx-auto ", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-3xl", children: "Related Articles" }),
        /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-3 py-7 gap-x-5 gap-y-8", children: [
          /* @__PURE__ */ jsx(ArticleCard, {}),
          /* @__PURE__ */ jsx(ArticleCard, {}),
          /* @__PURE__ */ jsx(ArticleCard, {})
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("section", { className: "max-w-[1200px] mx-auto flex items-center justify-center py-14 px-4", children: /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h4", { className: "text-3xl text-center py-5", children: "Sign up to our newsletter" }),
        /* @__PURE__ */ jsxs("div", { className: "flex shadow-3xl ", children: [
          /* @__PURE__ */ jsx("input", { type: "search", name: "", placeholder: "Enter Your Email", id: "", className: " rounded-l-xl md:w-[300px] w-full border-none outline outline-1 outline-slate-400 py-5" }),
          /* @__PURE__ */ jsxs("button", { className: "bg-greenish py-2 text-white md:px-10 px-3 rounded-r-xl flex items-center gap-x-4", children: [
            "Send",
            /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faTelegram })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx(MyFooter, {})
    ] })
  ] });
}
export {
  Welcome as default
};
