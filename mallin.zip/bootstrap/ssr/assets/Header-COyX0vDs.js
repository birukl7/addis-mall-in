import { jsxs, jsx, Fragment as Fragment$1 } from "react/jsx-runtime";
import { Fragment } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocation, faMailBulk, faPhone, faHome, faBuilding, faContactCard, faImage, faBlog, faDashboard, faX, faBars } from "@fortawesome/free-solid-svg-icons";
import { faTwitter, faFacebookF, faLinkedinIn, faTelegram, faInstagram } from "@fortawesome/free-brands-svg-icons";
import { Menu, Transition } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { usePage } from "@inertiajs/react";
function TopCard({ name, icon, address }) {
  return /* @__PURE__ */ jsxs("div", { className: "flex gap-x-5 items-center", children: [
    /* @__PURE__ */ jsx(FontAwesomeIcon, { icon, className: " text-greenish text-lg" }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col text-sm", children: [
      /* @__PURE__ */ jsx("span", { className: "", children: name }),
      /* @__PURE__ */ jsx("strong", { children: address })
    ] })
  ] });
}
function SocialIcon({ icon }) {
  return /* @__PURE__ */ jsx("a", { href: "", children: /* @__PURE__ */ jsx("span", { className: " hover:bg-greenish hover:text-white rounded-full p-2 px-3 cursor-pointer transition-all duration-200", children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon, className: "" }) }) });
}
function Top() {
  return /* @__PURE__ */ jsx("div", { className: "hidden md:block", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-5 items-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl", children: "Mall-In" }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-x-6", children: [
      /* @__PURE__ */ jsx(TopCard, { icon: faLocation, name: "Office, Address", address: "Sealite Mihret, Addis Ababa" }),
      /* @__PURE__ */ jsx(TopCard, { icon: faMailBulk, name: "Email Address", address: "melfantech@gmail.com" }),
      /* @__PURE__ */ jsx(TopCard, { icon: faPhone, name: "Drop a Line", address: "+251-94-055361" }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-x-2", children: [
        /* @__PURE__ */ jsx(SocialIcon, { icon: faTwitter }),
        /* @__PURE__ */ jsx(SocialIcon, { icon: faFacebookF }),
        /* @__PURE__ */ jsx(SocialIcon, { icon: faLinkedinIn })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-x-2", children: [
      /* @__PURE__ */ jsx("a", { href: "/login", className: "p-3 px-4 bg-greenish text-white hover:text-black hover:outline hover:outline-1 hover:bg-transparent transition duration-200 ease-linear", children: "Login" }),
      /* @__PURE__ */ jsx("a", { href: "/register", className: "p-3 bg-greenish text-white hover:text-black hover:outline hover:outline-1 hover:bg-transparent transition duration-200 ease-linear", children: "Sign Up" })
    ] })
  ] }) });
}
function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}
function Ddrop({ text }) {
  return /* @__PURE__ */ jsxs(Menu, { as: "div", className: "relative inline-block text-left", children: [
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs(Menu.Button, { className: "inline-flex w-full justify-center gap-x-1.5 rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50", children: [
      "English",
      /* @__PURE__ */ jsx(ChevronDownIcon, { className: "-mr-1 h-5 w-5 text-gray-400", "aria-hidden": "true" })
    ] }) }),
    /* @__PURE__ */ jsx(
      Transition,
      {
        as: Fragment,
        enter: "transition ease-out duration-100",
        enterFrom: "transform opacity-0 scale-95",
        enterTo: "transform opacity-100 scale-100",
        leave: "transition ease-in duration-75",
        leaveFrom: "transform opacity-100 scale-100",
        leaveTo: "transform opacity-0 scale-95",
        children: /* @__PURE__ */ jsx(Menu.Items, { className: "absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none", children: /* @__PURE__ */ jsxs("div", { className: "py-1", children: [
          /* @__PURE__ */ jsx(Menu.Item, { children: ({ active }) => /* @__PURE__ */ jsx(
            "a",
            {
              href: "#",
              className: classNames(
                active ? "bg-gray-100 text-gray-900" : "text-gray-700",
                "block px-4 py-2 text-sm"
              ),
              children: "አማርኛ"
            }
          ) }),
          /* @__PURE__ */ jsx(Menu.Item, { children: ({ active }) => /* @__PURE__ */ jsx(
            "a",
            {
              href: "#",
              className: classNames(
                active ? "bg-gray-100 text-gray-900" : "text-gray-700",
                "block px-4 py-2 text-sm"
              ),
              children: "Oromiffa"
            }
          ) }),
          /* @__PURE__ */ jsx(Menu.Item, { children: ({ active }) => /* @__PURE__ */ jsx(
            "a",
            {
              href: "#",
              className: classNames(
                active ? "bg-gray-100 text-gray-900" : "text-gray-700",
                "block px-4 py-2 text-sm"
              ),
              children: "ትግረኛ"
            }
          ) }),
          /* @__PURE__ */ jsx("form", { method: "POST", action: "#", children: /* @__PURE__ */ jsx(Menu.Item, { children: ({ active }) => /* @__PURE__ */ jsx(
            "button",
            {
              type: "submit",
              className: classNames(
                active ? "bg-gray-100 text-gray-900" : "text-gray-700",
                "block w-full px-4 py-2 text-left text-sm"
              ),
              children: "Espanol"
            }
          ) }) })
        ] }) })
      }
    )
  ] });
}
function Header({ func1, onclick }) {
  const url = usePage();
  const lists = [
    {
      id: 1,
      name: "Home",
      link: "/",
      icon: faHome,
      styles: `${url.url === "/" ? "outline outline-1 p-3 rounded-lg" : ""}`
    },
    {
      id: 2,
      name: "Mall Listing",
      link: "/malls",
      icon: faBuilding,
      styles: `${url.url === "/malls" || url.url === "/mall-detail" ? "outline outline-1 p-3 rounded-lg" : ""}`
    },
    {
      id: 3,
      name: "Free Space",
      link: "/spaces",
      icon: faContactCard,
      styles: `${url.url === "/spaces" ? "outline outline-1 p-3 rounded-lg" : ""}`
    },
    {
      id: 4,
      name: "Gallery",
      link: "/gallery",
      icon: faImage,
      styles: `${url.url === "/gallery" ? "outline outline-1 p-3 rounded-lg" : ""}`
    },
    {
      id: 4,
      name: "Blog",
      link: "/blogs",
      icon: faBlog,
      styles: `${url.url === "/blogs" ? "outline outline-1 p-3 rounded-lg" : ""}`
    },
    {
      id: 6,
      name: "Contact",
      link: "/contacts",
      icon: faContactCard,
      styles: `${url.url === "/contacts" ? "outline outline-1 p-3 rounded-lg" : ""}`
    },
    {
      id: 7,
      name: "Dashboard",
      link: "/dashboard",
      icon: faDashboard,
      styles: `${url.url === "/dashboard" || url.url === "/profile" ? "outline outline-1 sm:hidden md:block p-3 rounded-lg" : ""}`
    }
  ];
  return /* @__PURE__ */ jsxs(Fragment$1, { children: [
    /* @__PURE__ */ jsx("section", { className: "max-w-[1200px] mx-auto px-3", children: /* @__PURE__ */ jsx(Top, { text: "English" }) }),
    /* @__PURE__ */ jsxs("header", { className: "max-w-6xl mx-auto bg-slate-100 shadow-2xl rounded-lg sm:px-10 px-4 py-5 flex justify-between sticky top-0 z-40", children: [
      /* @__PURE__ */ jsxs("ul", { className: "flex md:items-center  gap-x-8 font-bold md:static fixed z-20 md:z-0 bottom-0 top-0 right-20 left-0 flex-col md:flex-row pt-8 md:pt-0 shadow-xl md:shadow-none md:bg-transparent bg-slate-200 items-start pl-20 md:pl-0 justify-start  md:flex  ", id: "navlinks", children: [
        /* @__PURE__ */ jsxs("div", { className: "md:hidden flex items-center justify-between ", children: [
          /* @__PURE__ */ jsx("button", { onClick: onclick, className: "-ml-16 -mt-12", children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faX, className: "" }) }),
          /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl ml-16 mb-4", children: "Mall In." })
        ] }),
        lists.map(
          (list) => /* @__PURE__ */ jsx("li", { className: "my-[18px] md:my-0 ", children: /* @__PURE__ */ jsxs("a", { href: list.link, className: `hover:text-slate-700 hover:underline flex md:block items-center gap-x-5 ${list.styles}  `, children: [
            /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: list.icon, className: "md:hidden text-greenish" }),
            list.name
          ] }) }, list.id)
        ),
        /* @__PURE__ */ jsxs("div", { className: "md:hidden border-t-[1.25px] border-black py-4 mt-5 border-b-[1.25px]", children: [
          /* @__PURE__ */ jsx(SocialIcon, { icon: faTelegram }),
          /* @__PURE__ */ jsx(SocialIcon, { icon: faInstagram }),
          /* @__PURE__ */ jsx(SocialIcon, { icon: faTwitter })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "md:hidden mt-10 -ml-3 flex gap-x-2", children: [
          /* @__PURE__ */ jsx("a", { href: "/login", className: "p-3 px-4 bg-greenish text-white hover:text-black hover:outline hover:outline-1 hover:bg-transparent transition duration-200 ease-linear", children: "Login" }),
          /* @__PURE__ */ jsx("a", { href: "/register", className: "p-3 bg-greenish text-white hover:text-black hover:outline hover:outline-1 hover:bg-transparent transition duration-200 ease-linear", children: "Sign Up" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("ul", { className: "flex gap-x-8 font-bold items-center sm:py-0 pt-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "sm:hidden flex items-center gap-x-3", children: [
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("button", { className: "z-50", onClick: func1, children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faBars, className: "text-2xl" }) }) }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("h1", { className: "font-bold", children: "MallIn" }) })
        ] }),
        /* @__PURE__ */ jsx(Ddrop, {}),
        /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("a", { href: "https://t.me/birukl_777", target: "_blank", className: " bg-yellowish text-white rounded-3xl md:p-3 py-[5px] px-[8px]   text-sm flex items-center gap-x-2 ", children: [
          "Contact Us ",
          /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faTelegram, className: "text-xl hidden md:block" })
        ] }) })
      ] })
    ] })
  ] });
}
export {
  Ddrop as D,
  Header as H,
  SocialIcon as S
};
