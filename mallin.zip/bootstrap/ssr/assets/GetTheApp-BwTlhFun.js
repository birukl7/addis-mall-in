import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import "react";
function GetTheApp({ googleBadge, iphoneBadge, img }) {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("section", { className: "bg-yellowish md:h-[500px] md:mt-20 px-5  mt-36 ", children: /* @__PURE__ */ jsx("div", { className: "max-w-[1200px] py-10 mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "flex md:flex-row flex-col items-center justify-between gap-x-10 text-white relative", children: [
    /* @__PURE__ */ jsxs("div", { className: "order-2", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-5xl pt-20 ", children: "Get the App" }),
      /* @__PURE__ */ jsx("p", { className: "p-4 text-xl", children: "Download the app" }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center md:flex-row flex-col", children: [
        /* @__PURE__ */ jsx("img", { src: googleBadge, alt: "", className: "w-44" }),
        /* @__PURE__ */ jsx("img", { src: iphoneBadge, alt: "", className: "w-44" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("img", { src: img, alt: "", className: "w-[80%] md:w-[45%] md:absolute static  md:right-0 md:-top-[60px] order-1 -mt-28 md:mt-0" })
  ] }) }) }) });
}
export {
  GetTheApp as G
};
