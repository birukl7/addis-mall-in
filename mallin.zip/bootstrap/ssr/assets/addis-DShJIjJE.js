const addis = "https://addismall.biruklemma.com/build/assets/addis-BrpzmJl6.jpg";
export {
  addis as a
};
