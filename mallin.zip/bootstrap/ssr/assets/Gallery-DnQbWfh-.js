import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import "react";
import { H as Header } from "./Header-COyX0vDs.js";
import { a as addis } from "./addis-DShJIjJE.js";
import { G as GetTheApp } from "./GetTheApp-BwTlhFun.js";
import { g as google, r as rust } from "./phone-mpckup-D1gSHcVV.js";
import { M as MyFooter } from "./MyFooter-C_fqmKH9.js";
import "@fortawesome/react-fontawesome";
import "@fortawesome/free-solid-svg-icons";
import "@fortawesome/free-brands-svg-icons";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "@inertiajs/react";
function GalleyG1Big({ img, person }) {
  return /* @__PURE__ */ jsx("div", { className: "rounded-xl overflow-hidden bg-cover bg-center h-[450px] px-4 text-white relative", style: { backgroundImage: `url('${img}')` }, children: /* @__PURE__ */ jsxs("div", { className: "absolute bottom-0 p-3 pb-5", children: [
    /* @__PURE__ */ jsxs("p", { children: [
      "By ",
      person
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-x-3 py-1", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-xs bg-[#1f4961] rounded-full p-[1.25px] px-[5px] pr-[12px]", children: [
        /* @__PURE__ */ jsx("span", { children: "❤️" }),
        /* @__PURE__ */ jsx("span", { children: "3" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs bg-[#1f4961] rounded-full p-[1.25px] px-[5px] pr-[12px]", children: [
        /* @__PURE__ */ jsx("span", { children: "🔥" }),
        /* @__PURE__ */ jsx("span", { children: "6" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs bg-[#1f4961] rounded-full p-[1.25px] px-[5px] pr-[12px]", children: [
        /* @__PURE__ */ jsx("span", { children: "👍" }),
        /* @__PURE__ */ jsx("span", { children: "16" })
      ] })
    ] })
  ] }) });
}
function GalleyG1Small({ img, person }) {
  return /* @__PURE__ */ jsx("div", { className: "rounded-xl overflow-hidden bg-cover bg-center h-[350px] px-4 text-white relative", style: { backgroundImage: `url('${img}')` }, children: /* @__PURE__ */ jsxs("div", { className: "absolute bottom-0 p-3 pb-5", children: [
    /* @__PURE__ */ jsxs("p", { children: [
      "By ",
      person,
      " "
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-x-3 py-1", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-xs bg-[#1f4961] rounded-full p-[1.25px] px-[5px] pr-[12px]", children: [
        /* @__PURE__ */ jsx("span", { children: "❤️" }),
        /* @__PURE__ */ jsx("span", { children: "3" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs bg-[#1f4961] rounded-full p-[1.25px] px-[5px] pr-[12px]", children: [
        /* @__PURE__ */ jsx("span", { children: "🔥" }),
        /* @__PURE__ */ jsx("span", { children: "6" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs bg-[#1f4961] rounded-full p-[1.25px] px-[5px] pr-[12px]", children: [
        /* @__PURE__ */ jsx("span", { children: "👍" }),
        /* @__PURE__ */ jsx("span", { children: "26" })
      ] })
    ] })
  ] }) });
}
function GalleryGrid1({ object }) {
  return /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-3 gap-x-5 gap-y-7", children: [
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-y-7", children: [
      /* @__PURE__ */ jsx(GalleyG1Big, { img: object.img1, person: object.person1 }),
      /* @__PURE__ */ jsx(GalleyG1Small, { img: object.img1, person: object.person1 })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-y-7", children: [
      /* @__PURE__ */ jsx(GalleyG1Small, { img: object.img1, person: object.person1 }),
      /* @__PURE__ */ jsx(GalleyG1Big, { img: object.img1, person: object.person1 })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-y-7", children: [
      /* @__PURE__ */ jsx(GalleyG1Big, { img: object.img1, person: object.person1 }),
      /* @__PURE__ */ jsx(GalleyG1Small, { img: object.img1, person: object.person1 })
    ] })
  ] });
}
function GalleryGrid2({ object }) {
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("h1", { className: "text-4xl font-semibold py-10", children: "Popular Galleries" }),
    /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-3  gap-y-8 md:gap-y-0 gap-x-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-y-7", children: [
        /* @__PURE__ */ jsx(GalleyG1Small, { img: object.img1, person: object.person1 }),
        /* @__PURE__ */ jsx(GalleyG1Big, { img: object.img1, person: object.person1 })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-y-7", children: [
        /* @__PURE__ */ jsx(GalleyG1Big, { img: object.img1, person: object.person1 }),
        /* @__PURE__ */ jsx(GalleyG1Small, { img: object.img1, person: object.person1 })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-y-7", children: [
        /* @__PURE__ */ jsx(GalleyG1Small, { img: object.img1, person: object.person1 }),
        /* @__PURE__ */ jsx(GalleyG1Big, { img: object.img1, person: object.person1 })
      ] })
    ] })
  ] });
}
function Gallery() {
  const toggleMenu = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.toggle("hidden");
  };
  const toggleMenuClose = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.add("hidden");
  };
  const galleryOb = {
    img1: addis,
    person1: "Biruk Lemma"
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Header, { func1: toggleMenu, onclick: toggleMenuClose }),
    /* @__PURE__ */ jsxs("main", { onClick: toggleMenuClose, children: [
      /* @__PURE__ */ jsxs("section", { className: "max-w-[1200px] mx-auto px-5 md:pt-20 pt-5 pb-10", children: [
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("h1", { className: "text-4xl font-semibold py-5", children: "Our Gallery" }) }),
        /* @__PURE__ */ jsx(GalleryGrid1, { object: galleryOb }),
        /* @__PURE__ */ jsx(GalleryGrid2, { object: galleryOb })
      ] }),
      /* @__PURE__ */ jsx(GetTheApp, { googleBadge: google, iphoneBadge: google, img: rust }),
      /* @__PURE__ */ jsxs("section", { className: "grid md:grid-cols-5 grid-cols-3 max-w-[1200px] mx-auto gap-x-5 -mb-[120px] pt-[100px] px-3", children: [
        /* @__PURE__ */ jsx("div", { style: { backgroundImage: `url('${addis}')` }, className: "bg-cover bg-center h-[200px]" }),
        /* @__PURE__ */ jsx("div", { style: { backgroundImage: `url('${addis}')` }, className: "bg-cover bg-center h-[200px]" }),
        /* @__PURE__ */ jsx("div", { style: { backgroundImage: `url('${addis}')` }, className: "bg-cover bg-center h-[200px]" }),
        /* @__PURE__ */ jsx("div", { style: { backgroundImage: `url('${addis}')` }, className: "bg-cover bg-center h-[200px] md:block hidden" }),
        /* @__PURE__ */ jsx("div", { style: { backgroundImage: `url('${addis}')` }, className: "bg-cover bg-center h-[200px] md:block hidden" })
      ] }),
      /* @__PURE__ */ jsx("section", { className: "mt-20", children: /* @__PURE__ */ jsx(MyFooter, { bgColor: "bg-slate-200 pt-20", youWant: true }) })
    ] })
  ] });
}
export {
  Gallery as default
};
