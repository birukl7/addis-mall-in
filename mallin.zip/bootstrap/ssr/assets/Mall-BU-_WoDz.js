import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { H as Header, D as Ddrop } from "./Header-COyX0vDs.js";
import { F as FIlterContainer, M as MallCard } from "./FIlterContainer-B3Xj9lfK.js";
import "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { M as MyFooter } from "./MyFooter-C_fqmKH9.js";
import { usePage } from "@inertiajs/react";
import "@fortawesome/free-brands-svg-icons";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "./Selector-DjJJhMdL.js";
import "react-icons/bi";
import "react-icons/ai";
const rating1 = "https://addismall.biruklemma.com/build/assets/rating-10-BoEVk2nS.png";
const rating05 = "https://addismall.biruklemma.com/build/assets/rating-35-Cl4X8EdV.png";
function Mall() {
  const { envVariables } = usePage().props;
  const toggleMenu = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.toggle("hidden");
  };
  const toggleMenuClose = () => {
    const navlinks = document.querySelector("#navlinks");
    navlinks.classList.add("hidden");
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Header, { func1: toggleMenu, onclick: toggleMenuClose }),
    /* @__PURE__ */ jsxs("main", { onClick: toggleMenuClose, children: [
      /* @__PURE__ */ jsx("section", { className: "max-w-[1300px] w-full mx-auto  items-center justify-center px-5 mt-24", children: /* @__PURE__ */ jsx(FIlterContainer, { url: envVariables.APP_URL }) }),
      /* @__PURE__ */ jsxs("section", { className: "max-w-[1200px] mx-auto mt-12 mb-4 px-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center mb-5", children: [
          /* @__PURE__ */ jsx("h2", { className: "font-bold", children: "Showing Resullts " }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("strong", { children: "Sort By      " }),
            /* @__PURE__ */ jsx(Ddrop, {})
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-5", children: [
          /* @__PURE__ */ jsx(MallCard, { rating: rating1, num: 1, img: "images/mall-6.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 2, img: "images/mall-3.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, img: "images/mall-2.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating1, num: 1, img: "images/mall-4.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 4, img: "images/mall-7.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, img: "images/mall-8.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating1, num: 1, img: "images/mall-9.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 6, img: "images/mall-6.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 7, img: "images/mall-4.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, img: "images/mall-2.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating1, num: 1, img: "images/mall-4.jpg" }),
          /* @__PURE__ */ jsx(MallCard, { rating: rating05, num: 4, img: "images/mall-7.jpg" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center py-2 justify-center mt-20 gap-x-3 text-xs", children: [
          /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowLeft, className: "p-1 outline-1 outline-slate-600  outline rounded-full" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full bg-greenish text-white cursor-pointer", children: "01" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full hover:bg-greenish hover:text-white cursor-pointer", children: "02" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full hover:bg-greenish hover:text-white cursor-pointer", children: "03" }),
          /* @__PURE__ */ jsx("span", { className: "p-1 outline-1 outline-slate-600  outline rounded-full hover:bg-greenish hover:text-white cursor-pointer", children: "04" }),
          /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faArrowRight, className: "p-1 outline-1 outline-slate-600  outline rounded-full" })
        ] })
      ] }),
      /* @__PURE__ */ jsx(MyFooter, { youWant: true })
    ] })
  ] });
}
export {
  Mall as default
};
