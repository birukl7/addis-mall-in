const google = "https://addismall.biruklemma.com/build/assets/google-play-badge-BAXiFmDF.png";
const rust = "https://addismall.biruklemma.com/build/assets/phone-mpckup-CAGzV0K4.png";
export {
  google as g,
  rust as r
};
